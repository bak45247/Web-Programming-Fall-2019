﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Survivor.Services
{
    public class UserNameProvider : IUserNameProvider
    {
        public string UserName => "bak45247";
    }
}
