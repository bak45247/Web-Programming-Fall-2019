﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Assignment_4.Entities
{
    public class ViewEntity
    {
        public string ViewDate { get; set; }


    }
}
