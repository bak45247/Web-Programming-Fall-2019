﻿namespace Portal.Entities.V1U0
{
    public class UserEntity
    {
        public string Username { get; set; }
        public string Password { get; set; }
    }
}
